import streamlit as st
import numpy as np
from sklearn.preprocessing import StandardScaler

def preprocess_data(df):
    numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
    features = st.multiselect(
        "Select features for clustering",
        numeric_cols,
        default=numeric_cols[:2]
    )

    if len(features) < 2:
        st.warning("Select at least two numeric features.")
        return None, None

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(df[features])
    return features, X_scaled

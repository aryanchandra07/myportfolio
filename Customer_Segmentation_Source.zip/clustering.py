from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

def elbow_method(X):
    wcss = []
    for k in range(2, 11):
        model = KMeans(n_clusters=k, random_state=42, n_init=10)
        model.fit(X)
        wcss.append(model.inertia_)
    return wcss

def run_kmeans(df, X, k):
    model = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = model.fit_predict(X)
    df["Cluster"] = labels
    score = silhouette_score(X, labels)
    return df, labels, score

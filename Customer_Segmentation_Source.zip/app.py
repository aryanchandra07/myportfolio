import streamlit as st
from data_loader import load_data
from preprocessing import preprocess_data
from clustering import run_kmeans, elbow_method
from visualization import plot_elbow, plot_clusters
from utils import cluster_summary

st.title("Customer Segmentation using K-Means Clustering")

st.markdown("""
### 👋 Welcome
Upload a customer dataset (CSV) containing numeric fields such as **Annual Income** and **Spending Score**
to perform customer segmentation using **K-Means clustering**.
""")

df = load_data()


if df is not None:
    features, X_scaled = preprocess_data(df)

    if X_scaled is not None:
        wcss = elbow_method(X_scaled)
        plot_elbow(wcss)

        k = st.slider("Select number of clusters (K)", 2, 10, 3)
        df_clustered, labels, score = run_kmeans(df, X_scaled, k)

        st.success(f"Silhouette Score: {score:.3f}")
        plot_clusters(df_clustered, features)
        cluster_summary(df_clustered, features)

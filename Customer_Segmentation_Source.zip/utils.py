import streamlit as st

def cluster_summary(df, features):
    st.subheader("Cluster Summary")
    summary = df.groupby("Cluster")[features].mean()
    st.dataframe(summary)

import streamlit as st
import matplotlib.pyplot as plt

def plot_elbow(wcss):
    st.subheader("Elbow Method")
    fig, ax = plt.subplots()
    ax.plot(range(2, 11), wcss, marker="o")
    ax.set_xlabel("Number of Clusters")
    ax.set_ylabel("WCSS")
    st.pyplot(fig)

def plot_clusters(df, features):
    st.subheader("Cluster Visualization")
    fig, ax = plt.subplots()
    scatter = ax.scatter(
        df[features[0]],
        df[features[1]],
        c=df["Cluster"],
        cmap="viridis"
    )
    ax.set_xlabel(features[0])
    ax.set_ylabel(features[1])
    st.pyplot(fig)
